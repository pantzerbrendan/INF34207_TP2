#!/usr/bin/env bash

g++ -Wall -Wextra -std=c++11 newton.cpp -o newton
g++ -D__UNIT_TEST__ -Wall -Wextra -std=c++11 classe.cpp -o classe
