#include <iostream>

class bidule
{
 // les defines, malgré qu'en général, ça mène à du
 // code pas très joli, peuvent être excusés pour les
 // tests unitaires pour permettre d'effectuer des tests
 // + complets sur les détails interne de la classe,
 // sans faire que nous nous retrouvions avec une pléthore
 // byzantine d'accesseurs.
 //
 #ifdef __UNIT_TEST__
     public:
 #else
     private:
 #endif

    // publiquement accessible SEULEMENT pour les
    // tests unitaires!
    int x;

 public:

 bidule(int x_) : x(x_)
  {
   #ifdef __DEBUG_MODE__
   
   #endif
  }
};



int main()
 {
  bidule z(3);

  // code valide uniquement lors des tests
  // unitaires
  //
  #ifdef __UNIT_TEST__
  std::cout << z.x << std::endl;
  if (z.x!=2)
   return 1; // erreur du test!
  #endif

  return 0;
 }
 
