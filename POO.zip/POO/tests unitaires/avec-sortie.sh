#!/usr/bin/env bash

# Script qui retourne EXIT_SUCCESS mais produit
# une sortie quelconque à la console pour simuler
# un programme qui imprime quelque chose (pour
# faire les tests de scripts)
#

echo Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis id dolor
echo finibus, hendrerit neque in, molestie lorem. Pellentesque habitant morbi
echo tristique senectus et netus et malesuada fames ac turpis egestas.

exit 0
