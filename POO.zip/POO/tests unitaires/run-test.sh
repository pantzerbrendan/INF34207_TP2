#!/usr/bin/env bash

# $@ est la chaîne de tous les arguments passés
# au script. Si le premier argument est un exécutable,
# alors la condition est vraie si l'exécutable retourne
# zéro (qui est EXIT_SUCCESS) et est fausse s'il retourne
# quelque chose d'autre (automatiquement faux s'il ne
# s'agit pas d'un exécutable). La sortie de la commande
# est redirigé dans un répertoire "outputs"
#

mkdir -p outputs

# Utiliser tous les arguments permet de passer des
# arguments au programme à tester.
#
if $@ &> outputs/$1.txt
then
    # -e fait qu'echo émule les "escape sequences"
    # http://ascii-table.com/ansi-escape-sequences.php
    #
    # escape [32m -> green foreground
    # escape [0m -> reset
    #
    echo -e "[  \e[32mOK\e[0m  ]" $1
else

    # escape [31m -> red foreground
    # escape [0m -> reset
    #
    echo -e "[ \e[31mFAIL\e[0m ]" $1
fi
