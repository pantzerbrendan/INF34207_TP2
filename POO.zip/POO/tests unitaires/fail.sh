#!/usr/bin/env bash


# Script minimaliste qui retourne toujours
# EXIT_FAILURE (1), simulant ainsi un programme
# qui retourne une condition d'erreur
#
exit 1
