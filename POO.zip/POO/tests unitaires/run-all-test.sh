#!/usr/bin/env bash

tests=( fail.sh success.sh avec-sortie.sh newton classe)

# Crée un sous-shell (délimité par les parenthèses)
# dont la sortie standard et la sortie d'erreur sont
# redigirés dans un pipe qui est affiché, grâce à tee,
# à la fois à la sortie standard et à la fois dans un
# fichier
(
    for z in ${tests[@]}
    do
        run-test.sh $z
    done
) 2>&1 \
    | tee resultat.txt
