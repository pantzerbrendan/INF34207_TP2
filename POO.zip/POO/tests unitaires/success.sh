#!/usr/bin/env bash

# Script minimaliste qui retourne toujours
# EXIT_SUCCESS (0), simulant ainsi un programme
# qui termine normalement sans erreur
#
exit 0
