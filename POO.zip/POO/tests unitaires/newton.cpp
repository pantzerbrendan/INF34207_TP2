#include <iostream>
#include <iomanip> // pour setprecision

#include <cstdlib> // pour std::rand()
#include <cmath> // pour fabs et sqrt

// normalement le programme serait segmenté
// comme un vrai projet, mais pour la démonstration,
// on va faire avec un programme monolithique


// algorithme de Newton-Rhapson
// pour calculer la racine carrée
//
// https://fr.wikipedia.org/wiki/M%C3%A9thode_de_Newton#Racine_carr.C3.A9e
//
float newton_sqrt(float n)
 {
  float x(n);
  float last(n);
  
  if (x)
   do
    {
     last=x;
     x=(x+n/x)/2;
    }
   while (x!=last);

  return x;
 }


int main()
 {
  for (int i=0;i<2000;i++)
   {
    // on choisit une valeur quelconque 
    int x=rand() % 10000;

    // ici, on compare notre version de l'algorithme
    // de racine carrée et une implémentation alternative
    // (mais sûre) de l'algorithme. Nous sommes chanceux,
    // la librairie standard contient une implémentation,
    // soit std::sqrt!
    //
    // Autrement, il nous aurait fallu disposer d'une
    // autre façon de faire nos tests!
    float y=newton_sqrt(x);
    float z=std::sqrt(x);

    if (std::fabs(z-y)>1e-5)
     {
      std::cout
       << std::setprecision(8)
       << "std::sqrt=" << z 
       << " newton_sqrt=" << y
       << " diff=" << z-y
       << std::endl;
      
      return 1; // le fail
     }
   }

  return 0;
 }
