#include <iostream>
#include <string>

// C++11 nous donne quelques fonctions de conversion autant de T à string 
// et de string à T... qu'au besoin on peut surcharger

// dans std::string, on trouve to_string(T) pour T=int, long, unsigned,
// float et les autres types numériques de base, et leurs inverses: stoi,
// stol, stoul, stof, etc.


class toaster
 {
  private:
  
      int i;
      float f;
  
  public:

      int get_the_int() const { return i; }
      float get_the_float() const { return f; }
  
  toaster(int i_, float f_)
   : i(i_),f(f_)
  {}
 };


// on pourrait le mettre dans le namespace std,
// mais ça pourrait porter à confusion avec les
// std::to_string qui existent déjà. La solution
// C# aurait été de mettre .to_string dans l'objet.
//
std::string to_string(const toaster & a)
 {
  return
   "{"+
   std::to_string(a.get_the_int())+
   ","+
   std::to_string(a.get_the_float())+
   "}";
 }

// pour l'opération inverse, on peut pousser la
// conversion dans le constructeur, ou dans une
// fonction qui décortique la représentation et
// appelle le constructeur
//
toaster stotoaster(const std::string & representation)
 {
  int virgule=representation.find(',',0);

  // on suppose ici que le format est bien gentil et
  // que personne n'a joué avec pour rajouter des espaces
  // ni ôté la virgule
  //
  return toaster(
    std::stoi(representation.substr(1,virgule-1)),
    std::stof(representation.substr(virgule+1,representation.size()-virgule-1))
   );
 }

int main()
 {
  // les routines de conversion pour les entiers font ce que l'on s'attend
  // d'elles:
  std::cout
   << 1231 << std::endl
   << "to_string=" << std::to_string(1231) << std::endl
   << "stoi(to_string(=" << std::stoi(std::to_string(1231)) << std::endl
   << -1241 << std::endl
   << "to_string=" << std::to_string(-1241) << std::endl
   << "stoi(to_string(=" << std::stoi(std::to_string(-1241)) << std::endl
   << std::endl
   ;
  
  // il faut cependant se mefier: les floats ne sont pas nécessairement
  // représentés de façon miniminale:
  std::cout
   << 3.14 << std::endl
   << "to_string=" << std::to_string(3.14) << std::endl
   << "stof(to_string(=" << std::stof(std::to_string(3.14)) << std::endl
   << 1e+30 << std::endl
   << "to_string=" << std::to_string(1e+30) << std::endl
   << "stod(to_string(=" << std::stod(std::to_string(1e+30)) << std::endl
   << std::endl
   ;


  toaster z(3,5);

  std::cout
   << to_string(z) << std::endl
   << to_string(stotoaster(to_string(z))) << std::endl
   ;
  
  return 0;
 }
